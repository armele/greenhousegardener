Supplemental Greenhouse Gardener climate item values for the Exteritio server pack.

Drop this folder, or a zip containing this folder's contents, into the server datapacks folder.
The files use "replace": false and add to the built-in Greenhouse Gardener defaults.

Compatibility is split by mod. If a mod is removed later, only that mod's climate item file
should fail to load; the built-in defaults and other compat files will remain usable.
